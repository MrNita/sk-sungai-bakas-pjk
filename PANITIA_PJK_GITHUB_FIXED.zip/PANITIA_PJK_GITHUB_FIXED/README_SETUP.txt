PANITIA PJK - GITHUB + FIREBASE ONLINE FILE SYSTEM

FILES
1. index.html - upload to GitHub repository root.
2. firebase-storage.rules - paste into Firebase Console > Storage > Rules.
3. firestore.rules - paste into Firebase Console > Firestore Database > Rules.

IMPORTANT FIREBASE SETUP
- Authentication > Sign-in method > Anonymous = Enabled.
- Storage must be enabled for the Firebase project.
- Firestore Database must be enabled.
- Publish both Rules files.

SUPPORTED FILES
DOC, DOCX, PDF, PNG, JPG, JPEG
Maximum 25 MB per file.

GITHUB PAGES
Repository > Settings > Pages > Deploy from a branch > main > / (root).
The repository root must contain index.html.
